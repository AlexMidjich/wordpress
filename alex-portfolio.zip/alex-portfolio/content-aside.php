<h3>ASIDE: <?php the_title(); ?></h3>
<small>Inlagt: <?php the_time('F j, Y'); ?></small>

<p><?php the_content(); ?></p>
			
			
<hr>	