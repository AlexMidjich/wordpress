		<footer>
			<p>&copy 2017 Alexander Midjich</p>
		</footer>

		<?php wp_footer(); ?>
		</section>
	</body>
</html>